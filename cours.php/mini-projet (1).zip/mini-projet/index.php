<?php
	$titre = 'Accueil';	
	require_once('./includes/header.php');
?>
	<main>
		<h1>Accueil</h1>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sint vitae sit adipisci quos possimus, eveniet odit quisquam? Porro molestias modi impedit nesciunt similique dolorum, deleniti atque quas temporibus ut accusantium!</p>
	</main>

<?php require_once('./includes/footer.php'); ?>